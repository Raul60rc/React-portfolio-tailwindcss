import React from 'react'

const Ptag = ({texto}) => {
    
    return (
    <p>{texto}</p>
  )
}

export default Ptag