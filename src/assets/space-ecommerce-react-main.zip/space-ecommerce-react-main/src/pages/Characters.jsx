import React from "react";
import Ptag from "../components/Atoms/Ptag";
import "./Characters.scss";

const Characters = () => {
  return (
    <div>
      <div className="characters">Characters</div>
      <Ptag/>
    </div>
  );
};

export default Characters;
