import React from "react";
import Ptag from "../components/Atoms/Ptag";

const Home = () => {
  return (
    <div>
      <div>Home</div>
      <Ptag texto = "Home" />
      <Ptag texto = "Luis" />
      <Ptag texto = "Mario" />
      <Ptag texto = "Guille" />
    </div>
  );
};

export default Home;
